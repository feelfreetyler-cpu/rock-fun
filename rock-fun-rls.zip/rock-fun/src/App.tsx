import { useEffect, useMemo, useState } from "react";
import { AuthGate } from "./components/AuthGate";
import { supabase } from "./lib/supabase";
import type { FindRow } from "./lib/types";
import { MapView } from "./components/MapView";
import { Feed } from "./components/Feed";
import { Button } from "./components/ui/button";

type Tab = "map" | "recent" | "mine";

/**
 * The main application component. It handles tab navigation, data fetching,
 * real‑time subscription to new finds, and passes props down to the various
 * subcomponents. Wrapped in AuthGate to enforce authentication.
 */
export default function App() {
  const [tab, setTab] = useState<Tab>("map");
  const [userId, setUserId] = useState<string>("");
  const [finds, setFinds] = useState<FindRow[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      setUserId(data.user?.id ?? "");
    });
  }, []);

  async function loadAll() {
    setLoading(true);
    const { data, error } = await supabase
      .from("finds")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(300);
    if (!error) setFinds((data as any) ?? []);
    setLoading(false);
  }

  useEffect(() => {
    loadAll();

    const channel = supabase
      .channel("finds-realtime")
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "finds" },
        (payload) => {
          const row = payload.new as FindRow;
          setFinds((prev) => [row, ...prev]);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const recent = useMemo(() => finds.slice(0, 50), [finds]);
  const mine = useMemo(() => finds.filter((f) => f.user_id === userId), [finds, userId]);

  return (
    <AuthGate>
      <div className="h-full w-full flex flex-col bg-white">
        {/* top bar */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100 bg-white">
          <div className="font-extrabold text-gray-900">Rock Fun</div>
          <div className="flex items-center gap-2">
            <Button className="bg-gray-200 text-gray-900 px-3 py-2" onClick={loadAll}>
              Refresh
            </Button>
            <Button
              className="bg-gray-900 px-3 py-2"
              onClick={async () => supabase.auth.signOut()}
            >
              Sign out
            </Button>
          </div>
        </div>

        {/* content */}
        <div className="flex-1 min-h-0">
          {loading ? (
            <div className="h-full grid place-items-center text-gray-600">Loading…</div>
          ) : tab === "map" ? (
            <MapView
              userId={userId}
              finds={finds}
              onCreated={(row) => setFinds((prev) => [row, ...prev])}
            />
          ) : tab === "recent" ? (
            <Feed rows={recent} />
          ) : (
            <div className="h-full overflow-y-auto bg-gradient-to-b from-blue-50 to-green-50 p-3">
              <div className="text-lg font-extrabold text-gray-900 px-1">My Finds (private)</div>
              <div className="mt-2">
                <Feed rows={mine} />
              </div>
            </div>
          )}
        </div>

        {/* bottom tabs */}
        <div className="border-t border-gray-100 bg-white p-2">
          <div className="grid grid-cols-3 gap-2">
            <Button
              className={tab === "map" ? "bg-blue-600" : "bg-gray-200 text-gray-900"}
              onClick={() => setTab("map")}
            >
              Map
            </Button>
            <Button
              className={tab === "recent" ? "bg-blue-600" : "bg-gray-200 text-gray-900"}
              onClick={() => setTab("recent")}
            >
              Recent
            </Button>
            <Button
              className={tab === "mine" ? "bg-blue-600" : "bg-gray-200 text-gray-900"}
              onClick={() => setTab("mine")}
            >
              My Finds
            </Button>
          </div>
        </div>
      </div>
    </AuthGate>
  );
}